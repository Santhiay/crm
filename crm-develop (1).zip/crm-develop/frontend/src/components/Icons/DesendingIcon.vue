<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="1"
    stroke-linecap="round"
    stroke-linejoin="round"
    class="lucide lucide-arrow-up-z-a"
  >
    <path d="m3 8 4-4 4 4" />
    <path d="M7 4v16" />
    <path d="M15 4h5l-5 6h5" />
    <path d="M15 20v-3.5a2.5 2.5 0 0 1 5 0V20" />
    <path d="M20 18h-5" />
  </svg>
</template>
