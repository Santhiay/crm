<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="1"
    stroke-linecap="round"
    stroke-linejoin="round"
    class="lucide lucide-file-audio-2"
  >
    <path d="M4 22h14a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v2" />
    <path d="M14 2v4a2 2 0 0 0 2 2h4" />
    <circle cx="3" cy="17" r="1" />
    <path d="M2 17v-3a4 4 0 0 1 8 0v3" />
    <circle cx="9" cy="17" r="1" />
  </svg>
</template>
