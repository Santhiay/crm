<template>
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <circle
      cx="8"
      cy="8"
      r="4.5"
      fill="transparent"
      stroke="currentColor"
      stroke-width="3"
    />
  </svg>
</template>
